class Student:

    #define __init__
    def __init__(self, name, dorm):
        self.name = name
        self.dorm = dorm